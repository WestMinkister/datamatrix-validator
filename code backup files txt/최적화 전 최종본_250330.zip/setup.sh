#!/bin/bash
apt-get update
apt-get install -y libdmtx0b libdmtx-dev
pip install pylibdmtx